const Test = () => {
  return (
    <>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
      <h1>Test 2</h1>
    </>
  );
};

export default Test;
