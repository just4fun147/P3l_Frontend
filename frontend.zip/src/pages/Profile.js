import logo from ".././assets/apple_logo_10-t2.jpg";
import { authUser, name, headersAuth } from "../Api";
import React, { useEffect, useState } from "react";
import axios from "axios";

const Profile = () => {
  const [users, setUser] = useState();
  useEffect(() => {
    async function fetchData() {
      axios
        .post(
          process.env.REACT_APP_BASEURL + "authUser",
          {},
          {
            headers: headersAuth,
          }
        )
        .then((response) => {
          setUser(response.data.OUT_DATA[0]);
        })
        .catch((error) => {
          // alert(error.response.data.OUT_STAT);
          console.log(error.response.data.OUT_STAT);
        });
    }
    fetchData();
  }, []);
  return (
    <>
      <div className="container mt-3 mb-5">
        <h3 className="mb-3">Your Profile</h3>
        <div className="row">
          <div className="col-md-5 border-end border-secondary">
            <div className="d-flex flex-column align-items-center text-center p-3 py-5">
              <span>
                <img
                  className="img-preview img-fluid mt-5"
                  src={logo}
                  style={{ clipPath: "circle()", width: "300px" }}
                  alt="user foto"
                ></img>
              </span>
              <span className="font-weight-bold mt-2">{users["name"]}</span>
              <span className="text-black-50">{users["email"]}</span>
              <span></span>
            </div>
          </div>
          <div className="col-md-7 mt-3">
            <p style={{ textAlign: "left" }}>Nama Lengkap</p>
            <input
              type="text"
              placeholder={users["name"]}
              className="form-control mb-3"
              style={{
                width: "100%",
                minWidth: "250px",
                display: "block",
                marginRight: "auto",
                marginLeft: "auto",
                backgroundColor: "#D9D9D9",
                borderRadius: "5px",
              }}
            ></input>
            <p style={{ textAlign: "left" }}>Email</p>
            <input
              type="text"
              placeholder={users["email"]}
              className="form-control mb-3"
              style={{
                width: "100%",
                minWidth: "250px",
                display: "block",
                marginRight: "auto",
                marginLeft: "auto",
                backgroundColor: "#D9D9D9",
                borderRadius: "5px",
              }}
            ></input>
            <p style={{ textAlign: "left" }}>No Handphone</p>
            <input
              type="text"
              placeholder={users["no_handphone"]}
              className="form-control mb-3"
              style={{
                width: "100%",
                minWidth: "250px",
                display: "block",
                marginRight: "auto",
                marginLeft: "auto",
                backgroundColor: "#D9D9D9",
                borderRadius: "5px",
              }}
            ></input>
            <p style={{ textAlign: "left" }}>Tanggal Lahir</p>
            <input
              type="date"
              value={users["tgl_lahir"]}
              className="form-control mb-3"
              style={{
                width: "100%",
                minWidth: "250px",
                display: "block",
                marginRight: "auto",
                marginLeft: "auto",
                backgroundColor: "#D9D9D9",
                borderRadius: "5px",
              }}
            ></input>
            <button
              className="btn btn-primary rounded-pill mb-1 mt-3"
              name="login"
              style={{
                width: "10%",
                minWidth: "75px",
                backgroundColor: "#0C1738",
                fontFamily: "Ubuntu",
                fontWeight: "bold",
                right: "0",
                marginLeft: "85%",
              }}
            >
              Save
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Profile;
